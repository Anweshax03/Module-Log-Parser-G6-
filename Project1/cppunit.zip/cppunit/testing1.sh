g++ -o testing1  Message.cpp Module.cpp Parser.cpp testing1.cpp -lcppunit
./testing1
